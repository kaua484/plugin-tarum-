require 'sketchup.rb'
module Taruma; module Moveis; VERSION='0.1.0'; end; end
